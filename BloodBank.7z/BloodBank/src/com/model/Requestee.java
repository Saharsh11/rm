package com.model;

import java.io.Serializable;
import java.util.Date;

public class Requestee implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String r_id;
	private String r_fname;
	private String r_lname;
	private String r_gender;
	private java.util.Date r_dob;
	private String r_btype;
	private String r_contact;
	private String r_eaddr;
	private String r_addr;
	private String r_doctor_name;
	private String r_hospital_name;
	private int q1;
	private int q2;
	private int q3;
	static int count=101;
	public Requestee(String r_fname, String r_lname, java.util.Date r_dob, String r_btype, String r_contact, String r_eaddr, String r_addr,
			String r_hospital_name,String dname,int q01,int q02,int q03) {
		//super();
		this.r_id= r_fname.substring(0,2) + count ;
		this.r_fname = r_fname;
		this.r_lname = r_lname;
		this.r_dob = r_dob;
		this.r_btype = r_btype;
		this.r_contact = r_contact;
		this.r_eaddr = r_eaddr;
		this.r_addr = r_addr;
		this.r_hospital_name = r_hospital_name;
		this.r_doctor_name=dname;
		this.q1=q01;
		this.q2=q02;
		this.q3=q03;
	}
	
	public Requestee() {
		
	}

	public synchronized String getR_fname() {
		return r_fname;
	}
	public synchronized void setR_fname(String r_fname) {
		this.r_fname = r_fname;
	}
	public synchronized String getR_lname() {
		return r_lname;
	}
	public synchronized void setR_lname(String r_lname) {
		this.r_lname = r_lname;
	}
	public synchronized String getR_gender() {
		return r_gender;
	}
	public synchronized void setR_gender(String r_gender) {
		this.r_gender = r_gender;
	}
	public synchronized java.util.Date getR_dob() {
		return r_dob;
	}
	public synchronized void setR_dob(java.util.Date r_dob) {
		this.r_dob = r_dob;
	}
	public synchronized String getR_btype() {
		return r_btype;
	}
	public synchronized void setR_btype(String r_btype) {
		this.r_btype = r_btype;
	}
	public synchronized String getR_contact() {
		return r_contact;
	}
	public synchronized void setR_contact(String r_contact) {
		this.r_contact = r_contact;
	}
	public synchronized String getR_eaddr() {
		return r_eaddr;
	}
	public synchronized void setR_eaddr(String r_eaddr) {
		this.r_eaddr = r_eaddr;
	}
	public synchronized String getR_addr() {
		return r_addr;
	}
	public synchronized void setR_addr(String r_addr) {
		this.r_addr = r_addr;
	}
	public synchronized String getR_doctor_name() {
		return r_doctor_name;
	}
	public synchronized void setR_doctor_name(String r_doctor_name) {
		this.r_doctor_name = r_doctor_name;
	}
	public synchronized String getR_hospital_name() {
		return r_hospital_name;
	}
	public synchronized void setR_hospital_name(String r_hospital_name) {
		this.r_hospital_name = r_hospital_name;
	}

	public synchronized int getQ1() {
		return q1;
	}

	public synchronized void setQ1(int q1) {
		this.q1 = q1;
	}

	public synchronized int getQ2() {
		return q2;
	}

	public synchronized void setQ2(int q2) {
		this.q2 = q2;
	}

	public synchronized int getQ3() {
		return q3;
	}

	public synchronized void setQ3(int q3) {
		this.q3 = q3;
	}

	public static synchronized int getCount() {
		return count;
	}
	public static synchronized void setCount(int count) {
		Requestee.count = count;
	}
	public static synchronized long getSerialversionuid() {
		return serialVersionUID;
	}
	public synchronized String getR_id() {
		return r_id;
	}
	
	
}