package com.model;

import java.io.Serializable;
import java.util.Date;

public class Employee implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private String e_id;
	private String e_name;
	private Date e_dob;
	private Date e_doj;
	private String e_contact;
	private String e_eaddr;
	private String e_addr;
	private String e_dept_id;
	static int count=0;
	
	public Employee(String e_name, Date e_dob, Date e_doj, String e_contact, String e_eaddr, String e_addr,
			String e_dept_id) {
		this.e_id=e_name.substring(0, 2) + count;
		this.e_name = e_name;
		this.e_dob = e_dob;
		this.e_doj = e_doj;
		this.e_contact = e_contact;
		this.e_eaddr = e_eaddr;
		this.e_addr = e_addr;
		this.e_dept_id = e_dept_id;
	}

	public synchronized String getE_id() {
		return e_id;
	}

	public synchronized String getE_name() {
		return e_name;
	}

	public synchronized void setE_name(String e_name) {
		this.e_name = e_name;
	}

	public synchronized Date getE_dob() {
		return e_dob;
	}

	public synchronized void setE_dob(Date e_dob) {
		this.e_dob = e_dob;
	}

	public synchronized Date getE_doj() {
		return e_doj;
	}

	public synchronized void setE_doj(Date e_doj) {
		this.e_doj = e_doj;
	}

	public synchronized String getE_contact() {
		return e_contact;
	}

	public synchronized void setE_contact(String e_contact) {
		this.e_contact = e_contact;
	}

	public synchronized String getE_eaddr() {
		return e_eaddr;
	}

	public synchronized void setE_eaddr(String e_eaddr) {
		this.e_eaddr = e_eaddr;
	}

	public synchronized String getE_addr() {
		return e_addr;
	}

	public synchronized void setE_addr(String e_addr) {
		this.e_addr = e_addr;
	}

	public synchronized String getE_dept_id() {
		return e_dept_id;
	}

	public static synchronized long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
