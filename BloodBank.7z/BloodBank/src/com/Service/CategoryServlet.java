package com.Service;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class CategoryServlet extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//super.doGet(req, resp);
		
		resp.setContentType("text/html");
		PrintWriter out=resp.getWriter();
		
		HttpSession se=req.getSession();
		
		if(se.isNew()){
			System.out.println("New Session encountered !!");
			System.out.println("Access Denied !!");
			
		}else{
			System.out.println("old Session encountered");
		}
		
		String unm=(String)se.getAttribute("uname");
		
		if(unm==null){
			System.out.println("UnAuthorized access !!");
		}else{
			out.println("<h1> welcome "+unm+"</h1>");
			out.println("<form>");
			out.println("<select name='Course'><option value='java' "+" selected>java</option>");
			out.println("<option value='. NET'>.net</option>");
			out.println("<option value='java'>JAVA</option></select>");
			out.println("</form>");
		}
	}
}
