package com.Service;
//date 26/7/2017 
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.Requestee;

public class Reg_req extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//super.doPost(req, resp);
		
		resp.setContentType("text/html");
		PrintWriter out=resp.getWriter();
		
		String fname = req.getParameter("fname");
		String lname = req.getParameter("lname");
		String gender = req.getParameter("gender");
		Date dob = BasicService.changeToUtilDate(req.getParameter("dob"));
		String contact = req.getParameter("contact");
		String email = req.getParameter("email");
		String btype = req.getParameter("btype");
		String addr = req.getParameter("addr");
		int q01 = Integer.parseInt(req.getParameter("disease"));
		int q03 = Integer.parseInt(req.getParameter("received"));
		String  hname = req.getParameter("hname");
		String dname = req.getParameter("dname");
		int q02 = Integer.parseInt(req.getParameter("donated"));
		
		//if(hname.equals("1")){q01=;}else if(dname.equals("1")){q02=true;}else if(donated.equals("1")){q03=true;}
		
		Requestee r= new Requestee(fname, lname, dob, btype, contact, email, addr, hname, dname, q01, q02, q03);
		
		out.println("requestee Object created . ");
		
	}
}
