package com.Initial;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Service.BasicService;

public class ForgotPwd extends HttpServlet{
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//super.doPost(req, resp);
		
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		
		String uid=req.getParameter("uid");
		
		String d = req.getParameter("doj");
		
		System.out.println("Date in String "+d);
		
		java.sql.Date dte=BasicService.changeToSqlDate(d);
		out.println(d);
		System.out.println(dte+" for userid "+uid);
		//DbmsService.userPwdChk(uid, dte);
	}
}
