package com.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import oracle.jdbc.OracleTypes;

public class DbmsService{
	static Connection conn=DButil.getMyConnection();
	
	//private static org.apache.log4j.Logger logs = Logger.getLogger(DbmsService.class);
	
	public static int chkCredentials(String unm,String pwd){
		
		//PropertyConfigurator.configure("./Rsources/log4j.properties");
		int ans=0;
		try {
			CallableStatement cs=conn.prepareCall("{call Chkcredentials_16049(?)}");
			//logs.info("stmt called");
			cs.registerOutParameter(1, OracleTypes.CURSOR);
			//logs.info("register out parametered ");

			int n=cs.executeUpdate();
			ResultSet rs=(ResultSet) cs.getObject(1);
			
			//logs.info("n : " + n);
			
			if(n>0){
			//logs.info("Statement Executed ... ");
			}//else{logs.fatal("Stmt not executed");}
			
			String uname,pass;
			
			while(rs.next()){
				
				System.out.println("\n in while ... \n ");
				
				uname=rs.getString(1);
				//logs.info("first column value added ... ");
				pass=rs.getString(2);
				
				//logs.info("Second column value added ... ");
			
			if((uname.equals(unm))&&(!pass.equals(pwd))||((!uname.equals(unm))&&(pass.equals(pwd)))){
				System.out.println("User Exists,incorrect userid or password !!");
				ans=2;
			}else if((uname.equals(unm))&&(pass.equals(pwd))){
				//logs.info("User Exists !!");
				ans=1;
			}
		}
		} catch (SQLException e) {
			//logs.fatal("Can't call stmt/user does not exists ... ");
			return 0;
		}
		return ans;
	}
	
	public static boolean userPwdChk(String uid, Date doj){
		boolean ans=false;
		try {
			CallableStatement cs = conn.prepareCall("{call forgotpwdchk_16049(?)}");
			cs.registerOutParameter(1, OracleTypes.CURSOR);
			
			int n= cs.executeUpdate();
			if(n>0){
			//	logs.info("Statement called !! ");
			}
			ResultSet rs=(ResultSet) cs.getObject(1);
			
			while(rs.next()){
				
				if((rs.getString(1).equalsIgnoreCase(uid))&&(rs.getDate(4).equals(doj))){
				//	logs.info("User Found ! ");
					ans=true;
				}
			}
			
		} catch (SQLException e) {
			//logs.fatal("User not Found !");
			return false;
		}
		return ans;
	}
	
	public static ResultSet retriveType(){
		ResultSet rs = null;
		
		try {
			CallableStatement cs = conn.prepareCall("{call RetriveBloodType_16049(?)}");
			
			cs.registerOutParameter(1, OracleTypes.CURSOR);
			
			cs.executeUpdate();
			
			rs = (ResultSet) cs.getObject(1);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rs;
	}
	
	public static void regInDB(){
		
		try {
			CallableStatement cs = conn.prepareCall("{call InsertInDb_16049(?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
