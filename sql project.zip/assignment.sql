drop table emp_xbbnlju;
create table emp_xbbnlju
(
emp_id number(5),
emp_name varchar2(50),
dept_name varchar2(50),
designation varchar2(50),
sal number(9,2),
status varchar2(20),
doj date
);

desc emp_xbbnlju;

insert into emp_xbbnlju values(102,'jack','java','ANALYST',40000,null,TO_DATE('15-AUG-2012'));
insert into emp_xbbnlju values(103,'SIM','java','TESTER',25000,null,TO_DATE('22-JAN-2014'));
insert into emp_xbbnlju values(901,'ANDREW','MAINFRAME','developer',45000,null,TO_DATE('11-NOV-2009'));
insert into emp_xbbnlju values(902,'JERRY','MAINFRAME','TESTER',35000,null,TO_DATE('14-JAN-2012'));
insert into emp_xbbnlju values(903,'TOM','MAINFRAME','ANALYST',50000,null,TO_DATE('21-JUL-2006'));

SELECT * FROM EMP_xbbnlju;

--1,3
create or replace function
salcal_16049(eid in number)
return number as
da constant number := 0.15;
hra constant number := 0.2;
ta constant number := 0.08;
allowance number;
salary number;
dj date;
dif number;
begin
 select sal,doj into salary,dj from emp_xbbnlju where emp_id=eid;
 dif := months_between(sysdate,dj)/12;
 if dif < 1 then
  allowance := 0;
 elsif dif >= 1 and dif<2 then
  allowance := 0.1;
 elsif dif >= 2 and dif < 4 then
  allowance := 0.2;
 else
  allowance := 0.3;
 end if;

salary := salary + (salary*da) + (salary*ta) + (salary*hra) + (salary*allowance);

return salary;

end salcal_16049;

variable res number;
EXECUTE :res := salcal_16049(103);
print res;

--2,4
create or replace procedure
callp_16049 as
inf emp_xbbnlju%rowtype;
avgsal emp_xbbnlju.sal%type;

cursor faith is select * from emp_xbbnlju;
begin--1
 open faith;
  if faith%notfound then--2
   raise_application_error(-20022,'no value in table');
  else
   begin--3
    loop--4
     fetch faith into inf;
     exit when faith%notfound;
     select avg(sal) into avgsal from emp_xbbnlju where dept_name=inf.dept_name;
   
     if inf.sal = avgsal then--5
      update emp_xbbnlju set status= 'equal' where emp_id = inf.emp_id;
     elsif inf.sal < avgsal then
      update emp_xbbnlju set status= 'lesser' where emp_id = inf.emp_id;
     else
      update emp_xbbnlju set status= 'greater' where emp_id = inf.emp_id;
     end if;--5
    end loop;--4
    end;--3
  end if;--2
 close faith;
end;--1

set serveroutput on;
execute callp_16049;

select * from emp_xbbnlju;

--5
create table emp_back_16049 as select * from emp_16049;

create or replace procedure
updt_16049(eid in number) as
upd emp%rowtype;
dif number;
higs number;
begin
 select * into upd from emp_16049 where upd.emp_id = eid;
 execute immediate 'drop table emp_back_16049';
 execute immediate 'create table emp_back_16049 as select * from emp_16049';
 dif:=months_between(sysdate,upd.doj)/12;
 if dif < 2 then
  higs := 0;
 elsif dif > 2 and dif < 5 then
  higs := 0.20;
 else
  higs := 0.25;
 end if;
 
 upd.sal := upd.sal + upd.sal*higs;
 update emp set sal=upd.sal where emp_id = upd.emp_id;
end updt_16049; 
 
 
 
 desc order_16049;
 
create or replace trigger at_insert_emp_16049
 before insert or delete on emp_xbbnlju
 declare
 mday varchar2(20);
 begin
 select TO_CHAR(sysdate,'Day') into mday from dual;
 DBMS_OUTPUT.PUT_LINE(mday);
 if mday = 'Saturday ' or mday = 'Tuesday  ' then
  raise_application_error(-20088,'Can not do update on '||mday);
 end if;
end;

insert into emp_xbbnlju values(908,'ram','mainframe','ANALYST',41000,null,TO_DATE('15-AUG-2014'));

desc order_history_16049;
create table order_table_16049(
id number(5),
qty number(10),
cost number(8,2)
);

insert into order_table_16049 values(1,10,100);
insert into order_table_16049 values(2,7,1000);
insert into order_table_16049 values(3,15,300);
insert into order_table_16049 values(4,22,50);
insert into order_table_16049 values(5,5,500);
insert into order_table_16049 values(6,10,120);

select * from order_table_16049;

create or replace trigger
after_update_order_table
before update 
on order_table_16049
for each row
begin
 insert into order_history_16049
 values(:old.id,:old.qty,:old.cost);
end;

update order_table_16049 set cost = 1200 where id=2;

select * from order_history_16049;