-------------------------------------------------------------------------------
---requester table 
create table blood_bank_requester_table(
rid varchar2(5) not null primary key,
fname varchar2(30) not null,
lname varchar2(30) not null,
gender varchar2(6) not null,
weight varchar2(5) not null,
dob DATE not null,
btype varchar2(4) not null,
contact varchar2(16) not null,
email varchar2(30) not null,
address varchar2(50) not null,
doctor varchar2(30) not null,
hospital varchar2(50) not null,
q1 number(1) not null,
q2 number(1) not null,
q3 number(1) not null,
Autologous number(1) not null
);
-------------------------------------------------------------------------------
----
create table blood_bank_requester_table1(
rid varchar2(5) not null primary key,
fname varchar2(30) not null,
lname varchar2(30) not null,
gender varchar2(6) not null,
dob DATE not null,
btype varchar2(4) not null,
contact varchar2(16) not null,
email varchar2(30) not null,
address varchar2(50) not null,
doctor varchar2(30) not null,
hospital varchar2(50) not null,
q1 number(1) not null,
q2 number(1) not null,
q3 number(1) not null,
Autologous number(1) not null
);
-------------------------------------------------------------------------------
---requester history table bb_requester_history_table
create table bb_requester_history_table(
rid varchar2(5) not null primary key,
fname varchar2(30) not null,
lname varchar2(30) not null,
gender varchar2(6) not null,
weight varchar2(5) not null,
dob DATE not null,
btype varchar2(4) not null,
contact varchar2(16) not null,
email varchar2(30) not null,
address varchar2(50) not null,
doctor varchar2(30) not null,
hospital varchar2(50) not null,
q1 number(1) not null,
q2 number(1) not null,
q3 number(1) not null,
Autologous number(1) not null
);
commit;
----------------------------------------------------------------------------------------------
---insert requester
create or replace procedure
InsertRequesterInDb_xbbnlju(rid in varchar2,fname in varchar2,lname in varchar2,gender in varchar2,
weight in varchar2,dob in DATE,btype in varchar2,contact in varchar2,email in varchar2,
address in varchar2,doctor in varchar2,hospital in varchar2,q1 in number,q2 in number,
q3 in number,autologous in number,flag out number) as
begin
insert into blood_bank_requester_table values(rid,fname,lname,gender,weight,dob,btype,contact,
email,address,doctor,hospital,q1,q2,q3,autologous);
flag := 1;
commit;
end InsertRequesterInDb_xbbnlju;
----------------------------------------------------------------------------------------------
create table blood_bank_for_match(
blood_id varchar2(5) primary key,
blood_type varchar2(4) not null
);
----------------------------------------------------------------------------------------------
insert into blood_bank_for_match values('b101','A+');
insert into blood_bank_for_match values('b102','A-');
insert into blood_bank_for_match values('b103','O+');
insert into blood_bank_for_match values('b104','O-');
insert into blood_bank_for_match values('b105','AB+');
insert into blood_bank_for_match values('b106','AB-');
insert into blood_bank_for_match values('b107','B+');
insert into blood_bank_for_match values('b108','B-');
select * from blood_bank_for_match;
-----------------------------------------------------------------------------------------------

create table blood_bank_to_match(
blood_id varchar2(5) primary key,
blood_type varchar2(4) not null
);
-----------------------------------------------------------------------------------------------
insert into blood_bank_to_match values('b101','A+');
insert into blood_bank_to_match values('b102','A-');
insert into blood_bank_to_match values('b103','O+');
insert into blood_bank_to_match values('b104','O-');
insert into blood_bank_to_match values('b105','AB+');
insert into blood_bank_to_match values('b106','AB-');
insert into blood_bank_to_match values('b107','B+');
insert into blood_bank_to_match values('b108','B-');
select * from blood_bank_to_match;
-----------------------------------------------------------------------------------------------
create or replace procedure
RetriveBloodType_16049(faith out SYS_REFCURSOR) as
begin
open faith for select * from blood_bank_to_match;
end RetriveBloodType_16049;
-----------------------------------------------------------------------------------------------
---employee table
create table Blood_bank_Emp_table(
emp_id varchar2(5) not null primary key,
fname varchar2(30) not null,
lname varchar2(30) not null,
gender varchar2(8) not null,
date_birth DATE not null,
date_join DATE not null,
btype varchar2(4) not null,
contact varchar2(10) not null,
email varchar2(30) not null,
address varchar2(50) not null,
recovery_id varchar2(30),
disease number(1) not null,
worked_earlier varchar2(3),
worked_history_type varchar2(20),
worked_location varchar2(30),
worked_exp number(3),
admin number(1) check(admin<2 and admin>=0)
);
-------------------------------------------------------------------------------------------------
insert into Blood_bank_Emp_table values('BE100','Saharsh','Bawankar','Male',TO_DATE('28-JAN-1995'),
TO_DATE('14-JUN-2017'),'A+',8844332211,'saharsh@gmail.com','pune','saharsh@gmail.com',0,'NO',
'no designation','no location',0,1);
insert into Blood_bank_Emp_credentials values('CR100','BE100','S@k3t!158');
-------------------------------------------------------------------------------------------------
------insert employee in db
create or replace procedure
InsertEmployeeInDb_16049(eid in varchar2,fnm in varchar2,lnm in varchar2,gender in varchar2,
dob in Date,doj in Date,btype in varchar2,contact in varchar2,email in varchar2,epass in varchar2,
address in varchar2,rec_id in varchar2,disease in number,workedEarlier in varchar2,
wHistoryType in varchar2,wLocation in varchar2,wExp in number,cid out varchar2) as 
v_credi Blood_bank_Emp_credentials.cred_id%type;
v_cred number(4);
begin
select max(TO_NUMBER(SUBSTR(cred_id,3)))+1 into v_cred from Blood_bank_Emp_credentials;
v_credi:='CR' || v_cred;
insert into Blood_bank_Emp_table values(eid,fnm,lnm,gender,dob,doj,btype,contact,email,address,rec_id,
disease,workedEarlier,wHistoryType,wLocation,wExp,0);
commit;
insert into Blood_bank_Emp_credentials values(v_credi,eid,epass);
select cred_id into cid from Blood_bank_Emp_credentials where emp_id=eid;
exception WHEN NO_DATA_FOUND then
v_credi:='CR' || '100';
insert into Blood_bank_Emp_credentials values(v_credi,eid,epass);
select cred_id into cid from Blood_bank_Emp_credentials where emp_id=eid;
commit;
end InsertEmployeeInDb_16049;
-------------------------------------------------------------------------------------------------

create table Blood_bank_Emp_credentials(
cred_id varchar2(5) not null primary key,
emp_id varchar2(5) not null,
passwd varchar2(30) not null,
foreign key(emp_id) references Blood_bank_Emp_table(emp_id)
);
-------------------------------------------------------------------------------------------------
create or replace procedure
Chkcredentials_16049(faith out SYS_REFCURSOR) as
begin
open faith for select * from Blood_bank_Emp_credentials;
end Chkcredentials_16049;
-------------------------------------------------------------------------------
create or replace procedure
DisplayEmpCred_160491(cred in varchar2,V_eid out varchar2,doj out Date) as
begin
select emp_id into v_eid from Blood_bank_Emp_credentials where cred_id = cred;
select date_join into doj from Blood_bank_Emp_table where emp_id = v_eid;
end DisplayEmpCred_160491;
-------------------------------------------------------------------------------------------------
create or replace procedure
DisplayEmpTable_16049(faith out SYS_REFCURSOR) as
begin
open faith for select * from Blood_bank_Emp_table;
end DisplayEmpTable_16049;
-------------------------------------------------------------------------------------------------
---table blood matching
create table blood_bank_blood_matching(
match_id varchar2(6) primary key,
recipient_blood_type varchar2(5) not null, 
Donor_blood_type varchar2(5) not null
);
-------------------------------------------------------------------------------------------------
insert into blood_bank_blood_matching values('bm201','A+','A+');
insert into blood_bank_blood_matching values('bm202','A+','A-');
insert into blood_bank_blood_matching values('bm203','A+','O+');
insert into blood_bank_blood_matching values('bm204','A+','O-');
insert into blood_bank_blood_matching values('bm205','A-','A-');
insert into blood_bank_blood_matching values('bm206','A-','O-');
insert into blood_bank_blood_matching values('bm207','O+','O+');
insert into blood_bank_blood_matching values('bm208','O+','O-');
insert into blood_bank_blood_matching values('bm209','O-','O-');
insert into blood_bank_blood_matching values('bm210','AB+','A+');
insert into blood_bank_blood_matching values('bm211','AB+','A-');
insert into blood_bank_blood_matching values('bm212','AB+','O+');
insert into blood_bank_blood_matching values('bm213','AB+','O-');
insert into blood_bank_blood_matching values('bm214','AB+','AB+');
insert into blood_bank_blood_matching values('bm215','AB+','AB-');
insert into blood_bank_blood_matching values('bm216','AB+','B+');
insert into blood_bank_blood_matching values('bm217','AB+','B-');
insert into blood_bank_blood_matching values('bm218','AB-','B-');
insert into blood_bank_blood_matching values('bm219','AB-','AB-');
insert into blood_bank_blood_matching values('bm220','AB-','O-');
insert into blood_bank_blood_matching values('bm221','AB-','A-');
insert into blood_bank_blood_matching values('bm222','B+','O+');
insert into blood_bank_blood_matching values('bm223','B+','O-');
insert into blood_bank_blood_matching values('bm224','B+','B+');
insert into blood_bank_blood_matching values('bm225','B+','B-');
insert into blood_bank_blood_matching values('bm226','B-','B-');
insert into blood_bank_blood_matching values('bm227','B-','O-');
-------------------------------------------------------------------------------------------------
---causes of RBC transfusion
create table causes_16049(
cause_id number(3) not null,
cause_type varchar(100) not null,
cause varchar(50) not null
);
drop table causes_16049;
-------------------------------------------------------------------------------------------------
insert into causes_16049 values(1,'Red BLood cell Transfusion','iron deficiency');
insert into causes_16049 values(2,'Red BLood cell Transfusion','acute anaemia');
insert into causes_16049 values(3,'Red BLood cell Transfusion','chronic anaemia');
insert into causes_16049 values(4,'Red BLood cell Transfusion','surgery');
insert into causes_16049 values(5,'Red BLood cell Transfusion','bone marrow transplantation');
insert into causes_16049 values(6,'Red BLood cell Transfusion','neonates');
insert into causes_16049 values(7,'Platelet Transfusion','platelet count is low');
insert into causes_16049 values(8,'Platelet Transfusion','bone marrow defect');
insert into causes_16049 values(9,'Platelet Transfusion','surgery');
insert into causes_16049 values(10,'Platelet Transfusion','bone marrow defect due tharapy');
insert into causes_16049 values(11,'Platelet Transfusion','total body irradiation (TBI)');
insert into causes_16049 values(12,'Plasma Transfusion','severe bleeding due surgery');
insert into causes_16049 values(13,'Plasma Transfusion','severe bleeding due childbirth');
insert into causes_16049 values(14,'Plasma Transfusion','severe bleeding due trauma');
insert into causes_16049 values(15,'Plasma Transfusion','low count due liver disease');
insert into causes_16049 values(16,'Granulocytes','severe infection after chemotherapy');
insert into causes_16049 values(17,'Granulocytes','severe infection after bone marrow transplantation');
-------------------------------------------------------------------------------------------------
--- retrive cause
create or replace procedure
retrive_cause_16049(ctype in varchar2,faith out SYS_REFCURSOR) as
begin
open faith for select * from causes_16049 where cause_type = ctype;
end retrive_cause_16049;
-------------------------------------------------------------------------------------------------
---blood price tag table
create table blood_quantity_16049(
item_id varchar2(5) not null primary key,
items varchar2(30) not null,
price number(7) not null,
units number(6) not null
);
-------------------------------------------------------------------------------------------------
insert into blood_quantity_16049 values('b101','A+',300.0,1000);
insert into blood_quantity_16049 values('b102','A-',300.0,1000);
insert into blood_quantity_16049 values('b103','O+',350.0,1000);
insert into blood_quantity_16049 values('b104','O-',350.0,1000);
insert into blood_quantity_16049 values('b105','AB+',350.0,1000);
insert into blood_quantity_16049 values('b106','AB-',400.0,1000);
insert into blood_quantity_16049 values('b107','B+',250.0,1000);
insert into blood_quantity_16049 values('b108','B-',250.0,1000);
insert into blood_item_quantity_16049 values('b109','Platelet',400.0,1000);
insert into blood_item_quantity_16049 values('b110','Plasma',200.0,1000);
insert into blood_item_quantity_16049 values('b111','Granulocyte',500.0,100);
-------------------------------------------------------------------------------------------------
create or replace procedure
chage_qty_16049(bid in varchar2, pri in number, nunits in number) as
begin
update blood_quantity_16049 set price = pri, units = nunits where item_id= bid;
end chage_qty_16049;
-------------------------------------------------------------------------------------------------
create or replace procedure
show_qty_16049(faith out SYS_REFCURSOR) as
begin
open faith for select * from blood_quantity_16049;
end show_qty_16049;
-------------------------------------------------------------------------------------------------
create or replace procedure
get_price_16049(itype in varchar2, out_price out number) as
begin
select price into out_price from blood_quantity_16049 where items = itype;
end get_price_16049;
------------------------------------------------------------------------------------
--- item price tag
-------------------------------------------------------------------------------------
---blood price tag table
create table blood_item_quantity_16049(
item_id varchar2(5) not null primary key,
items varchar2(30) not null,
price number(7) not null,
units number(6) not null
);
-------------------------------------------------------------------------------------------------
insert into blood_item_quantity_16049 values('bi101','Platelet',400.0,1000);
insert into blood_item_quantity_16049 values('bi102','Plasma',200.0,1000);
insert into blood_item_quantity_16049 values('bi103','Granulocyte',500.0,100);
-------------------------------------------------------------------------------------------------
create or replace procedure
show_item_qty_16049(faith out SYS_REFCURSOR) as
begin
open faith for select * from blood_item_quantity_16049;
end show_item_qty_16049;
-------------------------------------------------------------------------------------------------
create or replace procedure
change_item_price_16049(bid in varchar2, nunits in number) as
begin
update blood_item_quantity_16049 set units = nunits where item_id= bid;
end change_item_price_16049;
-------------------------------------------------------------------------------------------------
create or replace procedure
provide_required_blood_type(rtype in varchar2,faith out SYS_REFCURSOR) as
begin
open faith for select * from blood_bank_blood_matching where recipient_blood_type = rtype;
end;
-------------------------------------------------------------------------------------------------
drop table Blood_bank_request_done;
-------------------------------------------------------------------------------------------------
---generated request table
create table requesterStatusCheck(
request_id varchar2(8) primary key,
rid varchar2(6) not null,
roomNo varchar2(5),
requestType varchar2(50) not null,
transfusionType varchar2(50) not null,
reason varchar2(50) not null,
DonorType varchar2(5) not null,
units number(3) not null,
price number(7,2) not null,
status varchar2(10) not null,
foreign key(rid) references blood_bank_requester_table(rid)
);
-------------------------------------------------------------------------------------------------
create or replace procedure
insert_req_accident(req_id in varchar2,rid in varchar2,rno in varchar2,
DType in varchar2,nou in number,price in number,flag out number) as 
begin
flag:=0;
insert into Blood_bank_request_done values(req_id,rid,rno,'Accident',
'Red BLood Cell Transfusion','Accident',DType,nou,price,'Pending');
commit;
flag:=1;
end insert_req_accident;
-------------------------------------------------------------------------------------------------
create or replace procedure
insert_req_transfusion(req_id in varchar2,rid in varchar2,rno in varchar2,
tType in varchar2,reason in varchar2,DType in varchar2,nou in number,
price in number, flag out number) as 
begin
flag:=0;
insert into Blood_bank_request_done values(req_id,rid,rno,'Transfusion',tType,
reason,DType,nou,price,'Pending');
commit;
flag:=1;
end insert_req_transfusion;
-------------------------------------------------------------------------------------------------
create or replace procedure
Get_requester_table(faith out SYS_REFCURSOR) as
begin
open faith for select * from blood_bank_requester_table;
end;
-------------------------------------------------------------------------------------------------
create or replace procedure
Get_employee_table(faith out SYS_REFCURSOR) as
begin
open faith for select * from Blood_bank_Emp_table;
end;
-------------------------------------------------------------------------------------------------
create or replace procedure
get_generated_table(faith out SYS_REFCURSOR) as
begin
open faith for select * from Blood_bank_request_done;
end get_generated_table;
-------------------------------------------------------------------------------------------------
---getting max id(auto generation of id)
CREATE OR REPLACE PROCEDURE
GET_MAX_REQID(table_typ in varchar2,O_ID OUT NUMBER) AS 
BEGIN
if table_typ = 'BR' then
select max(TO_NUMBER(SUBSTR(rid,3)))+1 INTO O_ID FROM blood_bank_requester_table;
elsif table_typ = 'BE' then
select max(TO_NUMBER(SUBSTR(emp_id,3)))+1 INTO O_ID FROM Blood_bank_Emp_table;
elsif table_typ = 'GR' then
select max(TO_NUMBER(SUBSTR(request_id,3)))+1 INTO O_ID FROM Blood_bank_request_done;
end if;
commit;
END GET_MAX_REQID;
-------------------------------------------------------------------------------------------------
---display all request
create or replace procedure
displayReq_16049(faith out SYS_REFCURSOR) as
begin
open faith for select * from blood_bank_requester_table;
end displayReq_16049;
-------------------------------------------------------------------------------------------------
---moving into history table
create or replace procedure
moveToHistory_16049(in_id in varchar2,type in varchar2 , flag out number) as
req blood_bank_requester_table%rowtype;
begin
select * into req from blood_bank_requester_table where rid=in_id;
if type= 'Not Approved' then
insert into bb_requester_history_table values(req.rid,req.fname,req.lname,req.gender,
req.weight,req.dob,req.btype,req.contact,req.email,req.address,req.doctor,req.hospital,
req.q1,req.q2,req.q3,req.autologous);
delete from blood_bank_requester_table where rid = in_id;
update Blood_bank_request_done set status = 'Approved' where rid = req.rid;
flag:=1;
commit;
elsif type= 'Approved' then
insert into bb_requester_history_table values(req.rid,req.fname,req.lname,req.gender,
req.weight,req.dob,req.btype,req.contact,req.email,req.address,req.doctor,req.hospital,
req.q1,req.q2,req.q3,req.autologous);
delete from blood_bank_requester_table where rid = in_id;
update Blood_bank_request_done set status = 'Approved' where rid = req.rid;
flag:=1;
commit;
end if;
exception WHEN NO_DATA_FOUND then
flag:=0;
end;
-------------------------------------------------------------------------------------------------
----showing history table
create or replace procedure
displayHisReq_16049(faith out SYS_REFCURSOR) as
begin
open faith for select * from bb_requester_history_table;
end displayHisReq_16049;
-------------------------------------------------------------------------------------------------
----showing Employee by id
create or replace procedure
displayEmpByID_16049(crid in varchar2,faith out SYS_REFCURSOR) as
empid Blood_bank_Emp_credentials.emp_id%type;
begin
select emp_id into empid from Blood_bank_Emp_credentials where cred_id = crid;
open faith for select * from Blood_bank_Emp_table where emp_id = empid;
end displayEmpByID_16049;
-------------------------------------------------------------------------------------------------
create or replace procedure
updateEmp_16049(eid in varchar2,
fnm in varchar2,lnm in varchar2,gender in varchar2,dob in Date,doj in Date,btype in varchar2,
contact in varchar2,email in varchar2,address in varchar2,rec_id in varchar2,disease in number,
workedEarlier in varchar2,wHistoryType in varchar2,wLocation in varchar2,wExp in number,
flag out varchar2) as
begin
update Blood_bank_Emp_table
set fname = fnm, lname = lnm, gender = gender, date_birth = dob, date_join = doj, btype = btype,
email = email, address = address, recovery_id = rec_id, disease = disease,
worked_earlier = workedEarlier,worked_history_type = wHistoryType, worked_location = wLocation,
worked_exp = wExp, admin = 0 where emp_id = eid;
flag:=1;
exception when OTHERS THEN
flag:=0;
end;
-------------------------------------------------------------------------------------------------
----getting requested data
create or replace procedure
get_requested_status_16049(rid in String, faith out SYS_REFCURSOR) as
begin
open faith for select * from Blood_bank_request_done where request_id = rid;
end get_requested_status_16049;
-------------------------------------------------------------------------------------------------